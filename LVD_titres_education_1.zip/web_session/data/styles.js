var styles = [ {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Solid",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 50.0,
      "font-size" : 14,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(204,204,204)",
      "border-color" : "rgb(0,0,0)",
      "width" : 50.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 15.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(153,153,153)",
      "line-style" : "solid",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Directed",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 4.0,
      "color" : "rgb(0,102,204)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 50.0,
      "font-size" : 10,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(51,51,51)",
      "width" : 50.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "triangle",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(51,51,51)",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 12,
      "line-color" : "rgb(51,51,51)",
      "line-style" : "solid",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Custom Graphics Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(51,51,51)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "bottom",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 50.0,
      "font-size" : 12,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(255,255,255)",
      "width" : 50.0,
      "content" : "data(COMMON)"
    }
  }, {
    "selector" : "node[Degree > 18]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node[Degree = 18]",
    "css" : {
      "font-size" : 40
    }
  }, {
    "selector" : "node[Degree > 1][Degree < 18]",
    "css" : {
      "font-size" : "mapData(Degree,1,18,12,40)"
    }
  }, {
    "selector" : "node[Degree = 1]",
    "css" : {
      "font-size" : 12
    }
  }, {
    "selector" : "node[Degree < 1]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(64,64,64)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Minimal",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "roundrectangle",
      "border-width" : 0.0,
      "color" : "rgb(51,51,51)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 45.0,
      "font-size" : 10,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(0,0,0)",
      "width" : 45.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(51,51,51)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Big Labels",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(51,51,51)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 50.0,
      "font-size" : 24,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(0,0,0)",
      "width" : 50.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,0,102)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(102,102,102)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Marquee",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 40.0,
      "font-size" : 12,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(204,204,255)",
      "border-color" : "rgb(0,0,0)",
      "width" : 40.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(51,51,51)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(51,51,51)",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "galFiltered Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 2.0,
      "color" : "rgb(51,51,51)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 50.0,
      "font-size" : 12,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(204,204,204)",
      "width" : 50.0,
      "content" : "data(COMMON)"
    }
  }, {
    "selector" : "node[Degree > 18]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node[Degree = 18]",
    "css" : {
      "font-size" : 40
    }
  }, {
    "selector" : "node[Degree > 1][Degree < 18]",
    "css" : {
      "font-size" : "mapData(Degree,1,18,10,40)"
    }
  }, {
    "selector" : "node[Degree = 1]",
    "css" : {
      "font-size" : 10
    }
  }, {
    "selector" : "node[Degree < 1]",
    "css" : {
      "font-size" : 1
    }
  }, {
    "selector" : "node[gal1RGexp > 2,058]",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "node[gal1RGexp = 2,058]",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "node[gal1RGexp > 0,00000012][gal1RGexp < 2,058]",
    "css" : {
      "background-color" : "mapData(gal1RGexp,0,00000012,2,058,rgb(255,255,255),rgb(255,255,0))"
    }
  }, {
    "selector" : "node[gal1RGexp > -2,426][gal1RGexp < 0,00000012]",
    "css" : {
      "background-color" : "mapData(gal1RGexp,-2,426,0,00000012,rgb(0,102,204),rgb(255,255,255))"
    }
  }, {
    "selector" : "node[gal1RGexp = -2,426]",
    "css" : {
      "background-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[gal1RGexp < -2,426]",
    "css" : {
      "background-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 0.6666666666666666,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(153,153,153)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Ripple",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(153,153,153)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 50.0,
      "font-size" : 8,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(255,255,255)",
      "width" : 50.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,51)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(102,204,255)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Nested Network Style",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 2.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 40.0,
      "font-size" : 12,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(0,0,0)",
      "width" : 60.0,
      "content" : "data(shared_name)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "shape" : "rectangle"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "text-valign" : "bottom"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "background-color" : "rgb(255,255,255)"
    }
  }, {
    "selector" : "node[has_nested_network]",
    "css" : {
      "border-color" : "rgb(0,102,204)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(64,64,64)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Universe",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(255,255,255)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 30.0,
      "font-size" : 20,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(0,0,0)",
      "border-color" : "rgb(0,0,0)",
      "width" : 30.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(153,153,153)",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "jO",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "border-width" : 2.0,
      "color" : "rgb(6,6,6)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 12.0,
      "font-size" : 12,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(65,65,61)",
      "width" : 12.0,
      "shape" : "data(l_ind1)",
      "content" : "data(l_ind1)",
      "border-color" : "data(l_ind1)"
    }
  }, {
    "selector" : "node[l_i1 > 66 743]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "node[l_i1 = 66 743]",
    "css" : {
      "width" : 30.0
    }
  }, {
    "selector" : "node[l_i1 > 0][l_i1 < 66 743]",
    "css" : {
      "width" : "mapData(l_i1,0,66 743,10.0,30.0)"
    }
  }, {
    "selector" : "node[l_i1 = 0]",
    "css" : {
      "width" : 10.0
    }
  }, {
    "selector" : "node[l_i1 < 0]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "node[scoreY_ind1 > 1]",
    "css" : {
      "background-color" : "rgb(178,24,43)"
    }
  }, {
    "selector" : "node[scoreY_ind1 = 1]",
    "css" : {
      "background-color" : "rgb(214,96,77)"
    }
  }, {
    "selector" : "node[scoreY_ind1 > 0,80555556][scoreY_ind1 < 1]",
    "css" : {
      "background-color" : "mapData(scoreY_ind1,0,80555556,1,rgb(247,247,247),rgb(214,96,77))"
    }
  }, {
    "selector" : "node[scoreY_ind1 = 0,80555556]",
    "css" : {
      "background-color" : "rgb(247,247,247)"
    }
  }, {
    "selector" : "node[scoreY_ind1 < 0,80555556]",
    "css" : {
      "background-color" : "rgb(247,247,247)"
    }
  }, {
    "selector" : "node[scoreY_ind1 > 1]",
    "css" : {
      "background-color" : "rgb(178,24,43)"
    }
  }, {
    "selector" : "node[scoreY_ind1 = 1]",
    "css" : {
      "background-color" : "rgb(214,96,77)"
    }
  }, {
    "selector" : "node[scoreY_ind1 > 0,80555556][scoreY_ind1 < 1]",
    "css" : {
      "background-color" : "mapData(scoreY_ind1,0,80555556,1,rgb(247,247,247),rgb(214,96,77))"
    }
  }, {
    "selector" : "node[scoreY_ind1 = 0,80555556]",
    "css" : {
      "background-color" : "rgb(247,247,247)"
    }
  }, {
    "selector" : "node[scoreY_ind1 < 0,80555556]",
    "css" : {
      "background-color" : "rgb(247,247,247)"
    }
  }, {
    "selector" : "node[logl_i1 > 11,1086047]",
    "css" : {
      "height" : 1.0
    }
  }, {
    "selector" : "node[logl_i1 = 11,1086047]",
    "css" : {
      "height" : 227.924209222561
    }
  }, {
    "selector" : "node[logl_i1 > 2,07944154][logl_i1 < 11,1086047]",
    "css" : {
      "height" : "mapData(logl_i1,2,07944154,11,1086047,2.4390243902439024,227.924209222561)"
    }
  }, {
    "selector" : "node[logl_i1 = 2,07944154]",
    "css" : {
      "height" : 2.4390243902439024
    }
  }, {
    "selector" : "node[logl_i1 < 2,07944154]",
    "css" : {
      "height" : 1.0
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(245,3,25)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(98,59,243)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(243,193,59)",
      "source-arrow-shape" : "none",
      "width" : 100.0,
      "source-arrow-color" : "rgb(243,193,59)",
      "font-size" : 10,
      "line-color" : "rgb(243,193,59)",
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_NONCOMPETITIVE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_OTHER']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_UNCOMPETITIVE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'cofactor']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION_ALLOSTERIC']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'right']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_ALLOSTERIC']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'controlled']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'contains']",
    "css" : {
      "target-arrow-shape" : "circle"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_UNKMECH']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_IRREVERSIBLE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'INHIBITION_COMPETITIVE']",
    "css" : {
      "target-arrow-shape" : "tee"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION_UNKMECH']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'ACTIVATION_NONALLOSTERIC']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[sc > 100]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge[sc = 100]",
    "css" : {
      "width" : 10.431020442063247
    }
  }, {
    "selector" : "edge[sc > 16][sc < 100]",
    "css" : {
      "width" : "mapData(sc,16,100,0.24390243902439024,10.431020442063247)"
    }
  }, {
    "selector" : "edge[sc = 16]",
    "css" : {
      "width" : 0.24390243902439024
    }
  }, {
    "selector" : "edge[sc < 16]",
    "css" : {
      "width" : 1.0
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "BioPAX_SIF",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 2.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "background-opacity" : 0.49019607843137253,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 40.0,
      "font-size" : 12,
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,153,153)",
      "border-color" : "rgb(0,0,0)",
      "width" : 60.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "shape" : "hexagon"
    }
  }, {
    "selector" : "node[BIOPAX_TYPE = 'Complex']",
    "css" : {
      "background-color" : "rgb(153,204,255)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 4.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(0,0,0)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'controls-expression-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'chemical-affects']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-state-change-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-phosphorylation-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of-chemical']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'used-to-produce']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'consumption-controled-by']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'controls-production-of']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'catalysis-precedes']",
    "css" : {
      "target-arrow-shape" : "triangle"
    }
  }, {
    "selector" : "edge[interaction = 'interacts-with']",
    "css" : {
      "line-color" : "rgb(0,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'chemical-affects']",
    "css" : {
      "line-color" : "rgb(240,144,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-state-change-of']",
    "css" : {
      "line-color" : "rgb(0,0,192)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of']",
    "css" : {
      "line-color" : "rgb(112,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'consumption-controled-by']",
    "css" : {
      "line-color" : "rgb(255,51,0)"
    }
  }, {
    "selector" : "edge[interaction = 'reacts-with']",
    "css" : {
      "line-color" : "rgb(0,255,0)"
    }
  }, {
    "selector" : "edge[interaction = 'neighbor-of']",
    "css" : {
      "line-color" : "rgb(0,170,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-expression-of']",
    "css" : {
      "line-color" : "rgb(0,160,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-phosphorylation-of']",
    "css" : {
      "line-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of-chemical']",
    "css" : {
      "line-color" : "rgb(160,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'used-to-produce']",
    "css" : {
      "line-color" : "rgb(247,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'in-complex-with']",
    "css" : {
      "line-color" : "rgb(240,0,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-production-of']",
    "css" : {
      "line-color" : "rgb(0,204,240)"
    }
  }, {
    "selector" : "edge[interaction = 'catalysis-precedes']",
    "css" : {
      "line-color" : "rgb(112,0,160)"
    }
  }, {
    "selector" : "edge[interaction = 'interacts-with']",
    "css" : {
      "line-color" : "rgb(0,85,0)",
      "target-arrow-color" : "rgb(0,85,0)",
      "source-arrow-color" : "rgb(0,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'chemical-affects']",
    "css" : {
      "line-color" : "rgb(240,144,0)",
      "target-arrow-color" : "rgb(240,144,0)",
      "source-arrow-color" : "rgb(240,144,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-state-change-of']",
    "css" : {
      "line-color" : "rgb(0,0,192)",
      "target-arrow-color" : "rgb(0,0,192)",
      "source-arrow-color" : "rgb(0,0,192)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of']",
    "css" : {
      "line-color" : "rgb(112,0,0)",
      "target-arrow-color" : "rgb(112,0,0)",
      "source-arrow-color" : "rgb(112,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'consumption-controled-by']",
    "css" : {
      "line-color" : "rgb(255,51,0)",
      "target-arrow-color" : "rgb(255,51,0)",
      "source-arrow-color" : "rgb(255,51,0)"
    }
  }, {
    "selector" : "edge[interaction = 'reacts-with']",
    "css" : {
      "line-color" : "rgb(0,255,0)",
      "target-arrow-color" : "rgb(0,255,0)",
      "source-arrow-color" : "rgb(0,255,0)"
    }
  }, {
    "selector" : "edge[interaction = 'neighbor-of']",
    "css" : {
      "line-color" : "rgb(0,170,0)",
      "target-arrow-color" : "rgb(0,170,0)",
      "source-arrow-color" : "rgb(0,170,0)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-expression-of']",
    "css" : {
      "line-color" : "rgb(0,160,160)",
      "target-arrow-color" : "rgb(0,160,160)",
      "source-arrow-color" : "rgb(0,160,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-phosphorylation-of']",
    "css" : {
      "line-color" : "rgb(0,0,255)",
      "target-arrow-color" : "rgb(0,0,255)",
      "source-arrow-color" : "rgb(0,0,255)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-transport-of-chemical']",
    "css" : {
      "line-color" : "rgb(160,0,0)",
      "target-arrow-color" : "rgb(160,0,0)",
      "source-arrow-color" : "rgb(160,0,0)"
    }
  }, {
    "selector" : "edge[interaction = 'used-to-produce']",
    "css" : {
      "line-color" : "rgb(247,85,0)",
      "target-arrow-color" : "rgb(247,85,0)",
      "source-arrow-color" : "rgb(247,85,0)"
    }
  }, {
    "selector" : "edge[interaction = 'in-complex-with']",
    "css" : {
      "line-color" : "rgb(240,0,160)",
      "target-arrow-color" : "rgb(240,0,160)",
      "source-arrow-color" : "rgb(240,0,160)"
    }
  }, {
    "selector" : "edge[interaction = 'controls-production-of']",
    "css" : {
      "line-color" : "rgb(0,204,240)",
      "target-arrow-color" : "rgb(0,204,240)",
      "source-arrow-color" : "rgb(0,204,240)"
    }
  }, {
    "selector" : "edge[interaction = 'catalysis-precedes']",
    "css" : {
      "line-color" : "rgb(112,0,160)",
      "target-arrow-color" : "rgb(112,0,160)",
      "source-arrow-color" : "rgb(112,0,160)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default black",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(204,204,204)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "bottom",
      "text-halign" : "right",
      "border-opacity" : 1.0,
      "height" : 15.0,
      "font-size" : 12,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(0,153,0)",
      "width" : 15.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(0,153,0)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "default",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "roundrectangle",
      "border-width" : 0.0,
      "color" : "rgb(51,51,51)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 30.0,
      "font-size" : 12,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(51,255,255)",
      "border-color" : "rgb(0,102,153)",
      "width" : 70.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 3.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(102,102,102)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Sample1",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "center",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 40.0,
      "font-size" : 12,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(204,204,255)",
      "border-color" : "rgb(0,0,0)",
      "width" : 40.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(51,51,51)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 1.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(51,51,51)",
      "line-style" : "solid",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge[interaction = 'pp']",
    "css" : {
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge[interaction = 'pd']",
    "css" : {
      "line-style" : "dashed"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Metallic",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "ellipse",
      "border-width" : 0.0,
      "color" : "rgb(0,0,0)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "bottom",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 55.0,
      "font-size" : 14,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(204,204,204)",
      "border-color" : "rgb(0,0,0)",
      "width" : 55.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 1.0,
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 5.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(204,204,204)",
      "line-style" : "solid",
      "content" : "data(interaction)"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
}, {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.6.0",
  "target_cytoscapejs_version" : "~2.1",
  "title" : "Box",
  "style" : [ {
    "selector" : "node",
    "css" : {
      "shape" : "roundrectangle",
      "border-width" : 0.0,
      "color" : "rgb(102,102,102)",
      "text-opacity" : 1.0,
      "background-opacity" : 1.0,
      "text-valign" : "bottom",
      "text-halign" : "center",
      "border-opacity" : 1.0,
      "height" : 50.0,
      "font-size" : 8,
      "font-family" : "Dialog.plain",
      "font-weight" : "normal",
      "background-color" : "rgb(255,255,255)",
      "border-color" : "rgb(0,0,0)",
      "width" : 50.0,
      "content" : "data(name)"
    }
  }, {
    "selector" : "node:selected",
    "css" : {
      "background-color" : "rgb(255,255,0)"
    }
  }, {
    "selector" : "edge",
    "css" : {
      "target-arrow-shape" : "none",
      "font-family" : "SansSerif.plain",
      "font-weight" : "normal",
      "color" : "rgb(0,0,0)",
      "opacity" : 0.39215686274509803,
      "content" : "",
      "text-opacity" : 1.0,
      "target-arrow-color" : "rgb(0,0,0)",
      "source-arrow-shape" : "none",
      "width" : 2.0,
      "source-arrow-color" : "rgb(0,0,0)",
      "font-size" : 10,
      "line-color" : "rgb(204,204,204)",
      "line-style" : "solid"
    }
  }, {
    "selector" : "edge:selected",
    "css" : {
      "line-color" : "rgb(255,0,0)"
    }
  } ]
} ]